﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace FonePayDynamicQR.Helpers
{
    public class HashGenerator
    {
        public static string GenerateHash(string secretKey, string message)
        {
            try
            {
                byte[] byteKey = Encoding.UTF8.GetBytes(secretKey);
                string HMAC_SHA512 = "HmacSHA512";
                using (var sha512_HMAC = new HMACSHA512(byteKey))
                {
                    byte[] hashBytes = sha512_HMAC.ComputeHash(Encoding.UTF8.GetBytes(message));
                    return BytesToHex(hashBytes);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception while Hashing Using HMACSHA512: " + e.Message);
                return null;
            }
        }

        private static string BytesToHex(byte[] bytes)
        {
            char[] hexArray = "0123456789ABCDEF".ToCharArray();
            char[] hexChars = new char[bytes.Length * 2];
            for (int j = 0; j < bytes.Length; j++)
            {
                int v = bytes[j] & 0xFF;
                hexChars[j * 2] = hexArray[v >> 4];
                hexChars[j * 2 + 1] = hexArray[v & 0x0F];
            }
            return new string(hexChars);
        }
    }
}
