﻿using System;
using System.Drawing;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using FonePayDynamicQR.Helpers;
using QRCoder;
using static QRCoder.PayloadGenerator;
using ZXing.QrCode.Internal;

public class Program
{
    private static async Task Main(string[] args)
    {
        string secretKey = "dfd8a2f06c504abc8bdcc7c6ca281330";
        string Productkey = Guid.NewGuid().ToString("D").Substring(0, 20).ToLower();
        string MerchantCode = "2222280001746086";
        string UserId = "98560214992@fonepay.com";
        string UserPass = "Bbinod@123";

        string message = $"14,{Productkey},{MerchantCode},test1,test2";

        string url = "https://merchantapi.fonepay.com/api/merchant/merchantDetailsForThirdParty/thirdPartyDynamicQrDownload";

        string hash = HashGenerator.GenerateHash(secretKey, message);
        var payload = new
        {
            amount = 154,
            remarks1 = "test1",
            remarks2 = "test2",
            prn = Productkey,
            merchantCode = MerchantCode,
            dataValidation = hash,
            username = UserId,
            password = UserPass
        };

        using (var httpClient = new HttpClient())
        {
            var jsonPayload = JsonSerializer.Serialize(payload);
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine("API Response: " + responseContent);

                // Parse the response JSON
                dynamic jsonResponse = JsonSerializer.Deserialize<dynamic>(responseContent);

                // Get the URL from the JSON response
                string qrUrl = jsonResponse["url"];

                // Create QR code data
                QRCodeGenerator qrGenerator = new QRCodeGenerator();
                Url url1 = new Url(qrUrl);
                Payload payload = url1;
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(payload);

                // Create QR code graphic as bitmap
                QRCode qrCode = qrGenerator.CreateQrCode(qrCodeData);
                Bitmap qrCodeImage = qrCode.GetGraphic(20, Color.Black, Color.White);

                // Save the QR code image as a file
                string fileName = "qrcode.png";
                qrCodeImage.Save(fileName, System.Drawing.Imaging.ImageFormat.Png);

                Console.WriteLine($"QR code saved as {fileName}");
            }
            else
            {
                Console.WriteLine("Failed to call the API. Status code: " + response.StatusCode);
            }
        }
    }
}
